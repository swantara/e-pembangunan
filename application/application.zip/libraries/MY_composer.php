<?php
/**
 * Description of MY_Composer
 *
 * @author Rana
 */
class MY_Composer 
{
    function __construct() 
    {
        include("./vendor/autoload.php");
    }
}