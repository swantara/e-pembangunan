  <!-- Footer -->
  <div class="footer text-muted">
    &copy; 2017. <a href="#">Sekretariat Daerah Kabupaten Badung</a>
  </div>
  <!-- /footer -->

</body>
</html>